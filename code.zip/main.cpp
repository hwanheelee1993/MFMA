// sample main.cpp

#include <iostream>
#include <fstream>
#include "playlist.h"

using namespace std;

void DoAdd(PlayList& play_list)
{
	Song s;
	cout << "Enter song\n: ";
	cin >> s;
	play_list.AddSong(s);
}

void DoDelete(PlayList& play_list)
{
	Song del_song;
	cout << "Enter song to delete\n: ";
	cin >> del_song;

	if (play_list.DeleteSong(del_song))
	{
		cout << "Song successfully deleted\n";
	}
	else
	{
		cout << "No such song exists\n";
	}
}

bool Menu(PlayList& play_list)
{
	bool good;

	do
	{
		good = true;

		cout << "\n\nPlayList Program!\n"
			<< "\tA - Add a song\n"
			<< "\tD - Delete a song\n"
			<< "\tP - Play a song\n"
			<< "\tS - Show all songs\n"
			<< "\tT - Show playlist status\n"
			<< "\tF - Search\n"
			<< "\tW - Save a playlist\n"
			<< "\tQ - Quit\n: ";

		char choice;
		cin >> choice;
		fflush(stdin);

		switch (toupper(choice))
		{
		case 'A':
			DoAdd(play_list);
			break;

		case 'D':
			DoDelete(play_list);
			break;

		case 'P':
			play_list.Play();
			break;

		case 'S':
			play_list.ShowAll();
			break;

		case 'T':
			play_list.ShowStatus();
			break;

		case 'F':
			play_list.Search();
			break;

		case 'W':
			play_list.WriteList();
			break;

		case 'Q':
			return false;

		default:
			good = false;
		}
	} while (!good);

	return true;
}

int main()
{
	PlayList play_list;
	
	play_list.ReadList("menu.txt");
	/*
	play_list.AddSong(Song("see you again", "maroon 5", 3));
	play_list.AddSong(Song("uptown funk", "mark ronson", 2));
	play_list.AddSong(Song("trap queen", "fetty wap", 1));
	play_list.AddSong(Song("earned it", "the weekend", 3));
	play_list.AddSong(Song("sugar", "maroon 5", 1));
	play_list.AddSong(Song("love me like you do", "ellie goulding", 3));
	play_list.AddSong(Song("shut up and dance", "walk the moon", 4));
	play_list.AddSong(Song("want a lot", "ed sheeran", 2));
	play_list.AddSong(Song("G.D.F.R", "flo rida", 3));
	play_list.AddSong(Song("want to want me", "maroon 5", 1));
	play_list.AddSong(Song("somebody", "natalie la rose", 3));
	play_list.AddSong(Song("style", "taylor swift", 2));
	play_list.AddSong(Song("want to be", "omarion", 4));
	play_list.AddSong(Song("one last time", "ariana grande", 2));
	play_list.AddSong(Song("chains", "maroon 5", 72));
	*/

	while (Menu(play_list))
		;

	return 0;
}