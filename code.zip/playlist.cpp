//playlist.cpp

#include <iostream>
#include <cstring>
#include <iostream>
#include <string>
#include <Windows.h>
#include <ctime>
#include "playlist.h"
#include <cstdlib>
#include <new>
#include <fstream>

using namespace std;
enum PLAY_MODE {NORMAL, REPEAT, SHUFFLE};

//default constructor -> ���� ����� capacity�� 2�� �ǵ��� �Ѵ�.
PlayList::PlayList() : numofSong(0), play_index(0), capacity(0), first_node(nullptr){AddCapacity(2);};

//default deconstructor
PlayList::~PlayList(){
	for (int i = capacity; i >= 1; i--){
		delete &(*first_node)[i];
	} 
}

//capacity�� num��ŭ �ø���.
void PlayList::AddCapacity(int num){

	for (int i = 0; i < num; i++){
		if (capacity == 0){
			try{
				first_node = new Song_node;
			}
			catch (bad_alloc ex){
				ex.what();
				cout << "\n----------------------------------------\n";
				cout << "Error occurred!\nSystem will be closed...\n";
				cout << "----------------------------------------\n";
				Sleep(3000);
				exit(1);
			}
		}
		else{
			try{
				(*first_node)[capacity].next = new Song_node;
			}
			catch (bad_alloc ex){
				ex.what();
				cout << "\n----------------------------------------\n";
				cout << "Error occurred!\nSystem will be closed...\n";
				cout << "----------------------------------------\n";
				Sleep(3000);
				exit(1);
			}
			(*first_node)[capacity + 1].prev = &((*first_node)[capacity]);
		}
		capacity++;
	}
	system("cls");
};

//double the current size of capacity
void PlayList::doublesize(){
	AddCapacity(capacity);
	return;
}

//Add song to playlist 
void PlayList::AddSong(const Song& s){

	if (capacity == numofSong)
		doublesize();

	if (numofSong == 0){
		first_node->song = s;
		play_index = 1;
	}
	else{
		(*first_node)[numofSong + 1].song = s;
	}
	numofSong++;
	system("cls");
};

//capacity�� num��ŭ ���δ�
void PlayList::DeleteCapacity(int num){

	//capacity�� 2�� n�¸� �����ϹǷ�...
	if (capacity == 2)
		return;
	else{

		for (int i = 0; i < num; i++){
			delete &(*first_node)[capacity];
			(*first_node)[capacity - 1].next = nullptr;
			capacity--;
		}
	}
	return;
};

//halve the current size of capacity
void PlayList::halfsize(){
	DeleteCapacity(capacity / 2);
	return;
}


//Delete song from playlist
bool PlayList::DeleteSong(const Song& s){
	for (int i = 1; i <= numofSong; i++){
		if ((*first_node)[i].song == s){

			if (i == 1){
				if (numofSong == 1){
					(*first_node)[i].song = Song();
					play_index = 0;
				}
				else{
					Song_node* temp = first_node;
					first_node = &((*first_node)[i + 1]);
					first_node->prev = nullptr;
					delete temp;
					capacity -= 1;
					AddCapacity(1);
				}
			}

			else if (i == capacity){
				delete &((*first_node)[i]);
				(*first_node)[i - 1].next = nullptr;
				capacity -= 1;
				AddCapacity(1);
			}

			else{
				Song_node* temp = &(*first_node)[i];
				(*first_node)[i + 1].prev = (*first_node)[i].prev;
				(*first_node)[i - 1].next = (*first_node)[i].next;
				delete temp;
				capacity -= 1;
				AddCapacity(1);
			}

			numofSong--;

			if (play_index > numofSong)
				play_index--;

			if (numofSong <= capacity / 2)
				halfsize();

			return true;
		}

	}

	return false;
};

void PlayList::ReadList(const char* f) {
	ifstream fin(f);

	char line[100];
	int count = 0;
	string title = "";
	string artist = "";
	int time = 0;
	int mode = 0;

	static const int MAX_CHARS = 64;

	char title_s[MAX_CHARS];
	char artist_s[MAX_CHARS];

	while (fin.getline(line, sizeof(line))) {
		mode = count % 4;
		// cout << count << " " << mode << line << endl;
		switch (mode)
		{
		case 0:
			title = line;
			break;
		case 1:
			artist = line;
			break;
		case 2:
			// cout << "###" << line << endl;
			time = atoi(line);
			break;
		case 3:
			strcpy_s(title_s, title.c_str());
			strcpy_s(artist_s, artist.c_str());
			AddSong(Song(title_s, artist_s, time));
			break;
		default:
			break;
		}
		count++;
	}
	fin.close();
	return;
}

void PlayList::WriteList() {
	ofstream fout;
	string fname;
	cout << "Output File Name: ";
	cin >> fname;
	fout.open(fname);

	for (int i = 0; i < numofSong; i++) {
		//cout << '<' << i + 1 << '>' << endl;
		fout << (*first_node)[i + 1].song.artist << endl;
		fout << (*first_node)[i + 1].song.title << endl;
		fout << (*first_node)[i + 1].song.playtime << endl;
		fout << "@" << endl;
	}
	fout.close();
	Sleep(1000);
	system("cls");
	return;

}


//show all songs in playlist
void PlayList::ShowAll() const{
	char j = NULL;
	system("cls");
	cout << "----------------------------------" << endl;
	cout << "Now Showing all songs in playlist" << endl;
	cout << "----------------------------------" << endl;
	for (int i = 0; i < numofSong; i++){
		cout << '<' << i + 1 << '>' << endl;
		cout << "Artist: " << (*first_node)[i + 1].song.artist << endl;
		cout << "Title: " << (*first_node)[i + 1].song.title << endl;
		cout << "Playtime: " << (*first_node)[i + 1].song.playtime / 60 << " mintues " 
			 << (*first_node)[i + 1].song.playtime % 60 << " seconds\n\n";
	}
	cout << "----------------------------------" << endl;
	cout << "Press Q (q) to return to menu" << endl;
	while (j != 'q' && j != 'Q'){
		cin >> j;
	}
	system("cls");
	return;
};

void PlayList::Play(){
	int num = 0;
	int index;
	int playtime = 0;
	string line;
	PLAY_MODE mode;

	if (!play_index){
		cout << "Oooops! No song to play!" << endl;
		Sleep(1000);
		system("cls");
		return;
	}

	system("cls");
	cout << "---------------" << endl;
	cout << "Playing Setup" << endl;
	cout << "---------------" << endl;
	fflush(stdin);
	cout << "Enter Mode (1.n-Normal 2.r-Repeat 3.s-Shuffle 4. else - return to menu) : ";
	getline(cin, line);
	if (line == "1" || line == "n" || line == "N" || line == "Normal" || line == "normal"){
		mode = NORMAL;
		line = "Normal";
	}
	else if (line == "2" || line == "R" || line == "r" || line == "Repeat" || line == "repeat"){
		mode = REPEAT;
		line = "Repeat";
	}
	else if (line == "3" || line == "S" || line == "s" || line == "Shuffle" || line == "shuffle"){
		mode = SHUFFLE;
		line = "Shuffle";
	}
	else{
		cout << "Return to Menu!" << endl;
		cout << "---------------" << endl;
		Sleep(1000);
		system("cls");
		return;
	}

	cout << "Enter number of play : ";
	//cin >> num;
	scanf_s("%d", &num);
	fflush(stdin);

	if (num <= 0){
		cout << "---------------" << endl;
		cout << "Wrong Input!\n";
		cout << "Return to Menu!" << endl;
		cout << "---------------" << endl;
		Sleep(1000);
		system("cls");
		return;
	}

	system("cls");

	/* ��� ���� */
	cout << "-----------" << endl;
	cout << "Now Playing" << endl;
	cout << "-----------" << endl;
	switch (mode){

	/*�븻��� ���*/
	case NORMAL :
		index = play_index;
		for (int i = 0; i < num; i++){
			playtime += (*first_node)[index++].song.playtime;
			if (index > numofSong)
				index = 1;
		}
		cout << "Total Number of Songs : " << num << endl;
		cout << "Total Play Time       : " << playtime/60 << " minutes " << playtime%60 << " seconds\n";
		cout << "Play Mode             : " << line << "\n\n";

		for (int i = 0; i < num; i++){
			gotoxy(0, 6);
			cout << "Current Playing       : " << i + 1 << " / " << num << endl;
			LCDClock(play_index);
			Sleep(100);//���������� �Ѿ�� �� 0.1�� ���
		}

		ClearArea(Point(0, 9), Point(20, 16));
		gotoxy(0, 9);
		cout << "\n---------------------------\n";
		cout << "|===Now Played All songs==|\n";
		cout << "|return to main menu soon |\n";
		cout << "---------------------------\n";
		Sleep(5000);

		break;
	/*�ݺ���� ���*/
	case REPEAT:
		for (int i = 1; i <= numofSong; i++){
			playtime += (*first_node)[i].song.playtime;
		}
		playtime *= num;
		cout << "Total Number of Songs : " << num*numofSong << endl;
		cout << "Total Play Time       : " << playtime / 60 << " minutes " << playtime % 60 << " seconds\n";
		cout << "Play Mode             : " << line << "\n\n";

		for (int i = 0; i < num * numofSong; i++){
			gotoxy(0, 6);
			cout << "Current Playing       : " << i + 1 << " / " << num*numofSong << endl;
			LCDClock(play_index);
			Sleep(100);//���������� �Ѿ�� �� 0.1�� ���
		}

		ClearArea(Point(0, 9), Point(20, 16));
		gotoxy(0, 9);
		cout << "\n---------------------------\n";
		cout << "|===Now Played All songs==|\n";
		cout << "|return to main menu soon |\n";
		cout << "----------------------------\n";
		Sleep(5000);

		break;

	/*���� ��� ���*/
	case SHUFFLE:
		int* idx_rand = nullptr;
		try{
			idx_rand = new int[num]; // ������ ������ ������ �迭 ���� �� 0���� �ʱ�ȭ(�ߺ����� �ʾƾ� ��)
		}
		catch (bad_alloc ex){
			ex.what();
			cout << "\n----------------------------------------\n";
			cout << "Error occurred!\nSystem will be closed...\n";
			cout << "----------------------------------------\n";
			Sleep(3000);
			exit(1);
		}
		for (int i = 0; i < num; i++){
			idx_rand[i] = 0;
		}
		int repeat = num / numofSong; // �� ����Ŭ�� ��� ���°�
		int remainder = num % numofSong;

		//���������� ����Ŭ���� �ݺ��ǵ��� �迭 �Ҵ�
		srand(static_cast<unsigned int>(time(0)));
		for (int k = 0; k < repeat; k++){
			for (int i = 0; i < numofSong; i++){

				int flag;

				do{
					flag = 1;

					int gen_num = rand() % numofSong + 1;

					for (int j = 0; j < numofSong; j++){
						if (gen_num == idx_rand[j + k * numofSong]){
							flag = 0;
							break;
						}
					}
					if (flag){
						idx_rand[i + k * numofSong] = gen_num;
					}
				} while (!flag);
			}
		}

		for (int i = 0; i < remainder; i++){
			int flag;
			do{
				flag = 1;

				int gen_num = rand() % numofSong + 1;

				for (int j = 0; j < numofSong; j++){
					if (gen_num == idx_rand[repeat * numofSong + j]){
						flag = 0;
						break;
					}
				}
				if (flag){
					idx_rand[repeat * numofSong + i] = gen_num;
				}
			} while (!flag);
		}

		for (int i = 0; i < num; i++){
			playtime += (*first_node)[idx_rand[i]].song.playtime;
		}



		cout << "Total Number of Songs : " << num << endl;
		cout << "Total Play Time       : " << playtime / 60 << " minutes " << playtime % 60 << " seconds\n";
		cout << "Play Mode             : " << line << "\n\n";


		for (int i = 0; i < num; i++){
			gotoxy(0, 6);
			cout << "Current Playing       : " << i + 1 << " / " << num << endl;
			LCDClock(idx_rand[i]);
			Sleep(100);//���������� �Ѿ�� �� 0.1�� ���
		}

		play_index = idx_rand[num-1] + 1;
		if (play_index > numofSong)
			play_index = 1;

		ClearArea(Point(0, 9), Point(20, 16));
		gotoxy(0, 9);
		cout << "\n---------------------------\n";
		cout << "|===Now Played All songs==|\n";
		cout << "|return to main menu soon |\n";
		cout << "---------------------------\n";
		Sleep(5000);

		delete[] idx_rand;
		break;
	}

	system("cls");
	return;

};

/*LCDǥ�ÿ� �Լ�*/
void PlayList::LCDClock(int i){
	string line1[4];
	string line2[4];
	string line3[4];
	string line4[4];
	string line5[4];

	int time[4] = { 0 };
	int start_time;
	int nTime; 

	ClearArea(Point(0, 8), Point(200, 9));
	gotoxy(0, 8);
	cout << i << ". " << (*first_node)[i].song.title << " / " << (*first_node)[i].song.artist << " / "
		<< (*first_node)[i].song.playtime / 60 << " minutes " << (*first_node)[i].song.playtime % 60 << " seconds\n\n";
	
	start_time = GetTickCount();
	for (int n = 0; n <= (*first_node)[i].song.playtime;){

		gotoxy(0, 10);
		//ù��° line
		for (int i = 0; i < 4; i++){
			switch (time[i]){
			case 0: case 5: case 6: case 7: case 8: case 9: case 2: case 3:
				line1[i] = "----";
				break;
			case 1: case 4:
				line1[i] = "    ";
				break;
			}
			
		}
		cout << line1[0] << ' ' << line1[1] << "   " << line1[2] << ' ' << line1[3] << '\n';

		//�ι�° line
		for (int i = 0; i < 4; i++){
			switch (time[i]){
			case 0: case 4: case 7: case 8: case 9:
				line2[i] = "|  |";
				break;
			case 1: case 2: case 3: 
				line2[i] = "   |";
				break;
			case 5: case 6:
				line2[i] = "|   ";
				break;
			}

		}
		cout << line2[0] << ' ' << line2[1] << " * " << line2[2] << ' ' << line2[3] << '\n';

		//����° line
		for (int i = 0; i < 4; i++){
			switch (time[i]){
			case 0: 
				line3[i] = "|  |";
				break;
			case 1: 
				line3[i] = "   |";
				break;
			case 2: case 3: case 4: case 5: case 6: case 8: case 9:
				line3[i] = "----";
				break;
			case 7:
				line3[i] = "   |";
				break;
			}

		}
		cout << line3[0] << ' ' << line3[1] << "   " << line3[2] << ' ' << line3[3] << '\n';

		//�׹�° line
		for (int i = 0; i < 4; i++){
			switch (time[i]){
			case 0: case 6: case 8:
				line4[i] = "|  |";
				break;
			case 1: case 3: case 4: case 5: case 7: case 9:
				line4[i] = "   |";
				break;
			case 2:
				line4[i] = "|   ";
				break;
			}

		}
		cout << line4[0] << ' ' << line4[1] << " * " << line4[2] << ' ' << line4[3] << '\n';

		//�ټ���° line
		for (int i = 0; i < 4; i++){
			switch (time[i]){
			case 0: case 2: case 3: case 5: case 6: case 8: case 9:
				line5[i] = "----";
				break;
			case 1: case 4: case 7:
				line5[i] = "    ";
				break;
			}

		}
		cout << line5[0] << ' ' << line5[1] << "   " << line5[2] << ' ' << line5[3] << '\n';


		while (1){
			nTime = (GetTickCount() - start_time) / 1000;
			if (nTime > n){
				n = nTime;
				break;
			}
		}
		time[0] = (n / 60) / 10;
		time[1] = (n / 60) % 10;
		time[2] = (n % 60) / 10;
		time[3] = (n % 60) % 10;

	}

	play_index++;
	(*first_node)[i].numberplayed++;
	if (play_index > numofSong)
		play_index = 1;
	
};

void PlayList::ShowStatus() const{
	int totaltime = 0;
	char j = 0;
	for (int i = 1; i <= numofSong; i++){
		totaltime += (*first_node)[i].song.playtime;
	}

	system("cls");
	cout << "-----------------------\n";
	cout << "Now Showing Full Status\n";
	cout << "-----------------------\n";
	cout << "Number of Songs in the List : " << numofSong << endl;
	cout << "Capacity of List            : " << capacity << endl;
	cout << "Current Song Index          : " << play_index << endl;
	cout << "Total Playing Time          : " << totaltime/60 <<" mintues " << totaltime%60 << " seconds" << endl;
	cout << "---------\n";
	cout << "Playlist\n";
	cout << "---------\n";
	for (int i = 0; i < numofSong; i++){
		cout << '<' << i + 1 << " : " << (*first_node)[i + 1].numberplayed << " times played >\n";
		cout << "Artist: " << (*first_node)[i + 1].song.artist << endl;
		cout << "Title: " << (*first_node)[i + 1].song.title << endl;
		cout << "Playtime: " << ((*first_node)[i + 1].song.playtime) / 60 << " mintues " 
			 << ((*first_node)[i + 1].song.playtime) % 60 << " seconds\n\n";
	}
	cout << "----------------------------------" << endl;
	cout << "Press Q (q) to return to menu" << endl;
	while (j != 'q' && j != 'Q'){
		cin >> j;
	}
	system("cls");
	return;
};

/*Search�Լ��� Replacement�Լ����� Ȱ���ϱ� ���� Search�� ���� �Լ�*/
int* PlayList::Search_basic(const char a_or_s, char* key){
	int* arr = nullptr;
	try{
		arr = new int[numofSong]; //search�� ã�� �ε����� �����ϱ� ���� �迭 (�ִ� ���̴� numofSong�� ������ ����)
	}
	catch (bad_alloc ex){
		ex.what();
		cout << "\n----------------------------------------\n";
		cout << "Error occurred!\nSystem will be closed...\n";
		cout << "----------------------------------------\n";
		Sleep(3000);
		exit(1);
	}
	int match_num = 0;
	int flag = 0;

	//�迭 0���� �ʱ�ȭ
	for (int i = 0; i < numofSong; i++){
		arr[i] = 0;
	}

	//�迭�� �� ���ҿ� Search�� ���� ã�� ����ȣ ����
	if (a_or_s == 'a' || a_or_s == 'A'){
		for (int i = 1; i <= numofSong; i++)
		{
			if (strstr((*first_node)[i].song.artist, key))
			{
				arr[match_num++] = i;
				flag = 1;
			}
		}
	}
	else{
		for (int i = 1; i <= numofSong; i++)
		{
			if (strstr((*first_node)[i].song.title, key)){
				arr[match_num++] = i;
				flag = 2;
			}
		}
	}
	cout << endl;


	//Sort�� �̿��� ����
	if (flag){
		//Selection Sort -> flag�� 1�̸� ��Ƽ��Ʈ�� ���ϰ� 2�̸� Ÿ��Ʋ�� ���Ѵ�
		for (int i = 0; i < match_num - 1; i++){
			for (int j = i + 1; j < match_num; j++){
				if (strcmp((flag == 1) ? (*first_node)[arr[j]].song.artist : (*first_node)[arr[j]].song.title,
					(flag == 1) ? (*first_node)[arr[i]].song.artist : (*first_node)[arr[i]].song.title) < 0)
				{
					int temp = arr[j];
					arr[j] = arr[i];
					arr[i] = temp;
				}
			}
		}
		return arr;
	}
	else{
		return nullptr;
	}
};

/*Search_basic�� �̿��Ͽ� ã�� ����*/
void PlayList::Search(){

	int* arr = nullptr; //search_basic���� ã�� �ε����� �����ϱ� ���� �迭 (�ִ� ���̴� numofSong�� ������ ����)
	char a_or_s = NULL;
	char j = NULL;
	char key[Song::MAX_CHARS];
	int matchnum = 0;


	system("cls");
	cout << "Now Searching for What? : \n";
	cout << "A - Artist\n"
		 << "S - Song\n";

	cin >> a_or_s;
	fflush(stdin);

	if (a_or_s == 'a' || a_or_s == 'A')
		a_or_s = 'a';
	else if (a_or_s == 's' || a_or_s == 'S')
		a_or_s = 's';
	else {
		cout << "Wrong Input! gonna return to the menu\n";
		Sleep(1000);
		system("cls");
		return;
	}
	

	cout << "Enter Keywords : ";
	//cin.getline(key, Song::MAX_CHARS);
	cin >> key;
	fflush(stdin);

	arr = Search_basic(a_or_s, key);

	if (arr == nullptr)
	{
		cout << "No results Found! Return to menu soon...\n";
		Sleep(1000);
		system("cls");
		return;
	}
	else{

		for (int i = 0; i < numofSong; i++)
			if (arr[i] != 0)
				matchnum++;
			else
				break;

		system("cls");
		if (a_or_s == 'a'){
			cout << matchnum << " Results for Artist : " << key << " found (alphabetical order) : \n\n";
		}
		else{
			cout << matchnum << " Results for Title : " << key << " found (alphabetical order) : \n\n";
		}
		for (int i = 0; i < matchnum; i++){
			cout << i + 1 << " : " << (*first_node)[arr[i]].song.title << " / " << (*first_node)[arr[i]].song.artist << endl;
		}
		cout << "-----------------------------" << endl;
		cout << "Press Q (q) to return to menu" << endl;
		while (j != 'q' && j != 'Q'){
			cin >> j;
		}
		delete[] arr;
		system("cls");
	}
};

/*Search_basic�� �̿��Ͽ� ��ü���� ����*/
void PlayList::Replacement(){

	int* arr = nullptr; 
	char a_or_s = NULL;
	char j = NULL;
	char key[Song::MAX_CHARS];
	char change[Song::MAX_CHARS];
	char temporary[Song::MAX_CHARS];
	int choose = 0;
	int matchnum = 0;
	char* temp = nullptr;
	int length = 0;


	system("cls");
	cout << "Replacement for What? : \n";
	cout << "A - Artist\n"
		 << "S - Song\n";

	cin >> a_or_s;
	fflush(stdin);

	if (a_or_s == 'a' || a_or_s == 'A')
		a_or_s = 'a';
	else if (a_or_s == 's' || a_or_s == 'S')
		a_or_s = 's';
	else {
		cout << "Wrong Input! gonna return to the menu\n";
		Sleep(1000);
		system("cls");
		return;
	}


	cout << "Enter Keywords : ";
	cin.getline(key, Song::MAX_CHARS);
	fflush(stdin);

	arr = Search_basic(a_or_s, key);

	if (arr == nullptr)
	{
		cout << "No results Found! Return to menu soon...\n";
		Sleep(1000);
		system("cls");
		return;
	}
	else{

		for (int i = 0; i < numofSong; i++)
			if (arr[i] != 0)
				matchnum++;
			else
				break;

		system("cls");

		if (a_or_s == 'a'){
			cout << matchnum << " Results for Artist : " << key << " found (alphabetical order) : \n\n";
		}
		else{
			cout << matchnum << " Results for Title : " << key << " found (alphabetical order) : \n\n";
		}
		for (int i = 0; i < matchnum; i++){
			cout << i + 1 << " : " << (*first_node)[arr[i]].song.title << " / " << (*first_node)[arr[i]].song.artist << endl;
		}
		cout << "--------------------------\n";
		cout << "Choose one : ";
		//cin >> choose;
		scanf_s("%d", &choose);
		fflush(stdin);

		if ((choose > matchnum) || (choose <= 0)){
			cout << "Wrong Input! gonna return to the menu\n";
			Sleep(1000);
			delete[] arr;
			system("cls");
			return;
		}
		else{
			cout << "Change keyword to What? : ";
			cin.getline(change, Song::MAX_CHARS);
			cout << "change before : " << change << endl;
			fflush(stdin);

			//temp�� artist Ȥ�� title�� �ּҰ��� ����
			temp = (a_or_s == 'a') ? (*first_node)[arr[choose - 1]].song.artist : (*first_node)[arr[choose - 1]].song.title;

			if (strlen(change) + strlen(temp) - strlen(key) > Song::MAX_CHARS - 1)
			{
				cout << "Exceeded the Maximum length\n-----------------------------\nReturn to Menu Soon..." << endl;
				delete[] arr;
				Sleep(1000);
				system("cls");
				return;
			}

			cout << "-------------------\n";
			cout << "...Now Changing....\n";
			cout << "-------------------\n";
			int i = strlen(key) + (int)strstr(temp, key) - (int)temp; // i���� �ش� ���ڿ����� key�� ������ �ε����� ����
			int j = 0;
			char* start_key = strstr(temp, key); //start_key���� �ش� ���ڿ����� key���� ���۵Ǵ� �ּҸ� ����
			for (; temp[i] != '\0'; j++, i++){
				temporary[j] = temp[i]; //temporary �迭���� �ش� ���ڿ����� key�����ĺ��� null���ڱ����� ���ڿ� ����
			}
			temporary[j] = '\0';
			cout << "Temporary : " << temporary << endl;
			strcat_s(change, Song::MAX_CHARS, temporary);
			cout << "change after : " << change << endl;
			memmove(start_key, change, sizeof(char)*(strlen(change)+1));
			cout << "Changed Successfully to " << temp << '\n';
			cout << "-----------------------\n";
			cout << "Return to menu soon...\n";
			Sleep(3000);
			delete[] arr;
			system("cls");
			return;
		}
	}
};


/*Ư������ȭ�鿡 ����� ���� �Լ� ����*/
void gotoxy(int x, int y)
{
	COORD CursorPosition = { x, y };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), CursorPosition);
}

COORD Point(short x, short y)
{
	COORD point = { x, y };
	return point;
}

void ClearArea(COORD p1, COORD p2)
{
	for (int i = 0; i < p2.Y - p1.Y; i++)
	{
		gotoxy(p1.X, p1.Y + i);
		for (int j = 0; j < p2.X - p1.X; j++)
		{
			printf(" ");
		}
	}
}



